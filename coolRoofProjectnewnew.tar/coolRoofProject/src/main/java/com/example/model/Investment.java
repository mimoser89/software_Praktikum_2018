package com.example.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "investment")
public class Investment {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "investment_id")
	private int id;
	@Column(name = "userId")
	private int userId;
	@Column(name = "roofIds")
	private String roofIds;
	@NotEmpty(message = "*Please select a message")
	private String space;
	@Column(name = "magnitude")
	private int magnitude;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getRoofIds() {
		return roofIds;
	}
	public void setRoofIds(String roofIds) {
		this.roofIds = roofIds;
	}
	public String getSpace() {
		return space;
	}
	public void setSpace(String space) {
		this.space = space;
	}
	public int getMagnitude() {
		return magnitude;
	}
	public void setMagnitude(int magnitude) {
		this.magnitude = magnitude;
	}
	
	
	

}
