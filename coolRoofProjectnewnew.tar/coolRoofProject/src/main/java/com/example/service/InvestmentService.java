package com.example.service;

import com.example.model.Investment;
import com.example.model.User;

import java.util.List;

public interface InvestmentService {
	public List<Investment> findAll();
	public List<Investment> findByuserId(int userId);
	
	public void saveInvestment(Investment investment);
}
